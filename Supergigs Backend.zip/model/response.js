const response = {
  status: "",
  data: "",
  success: false,
};

module.exports = response;
