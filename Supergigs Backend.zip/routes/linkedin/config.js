module.exports = {
  'linkedinAuth': {
    'clientID': '8644tgrwzw20xi', // your App ID
    'clientSecret': 'wKXrPabzIU6dduSW', // your App Secret
    'callbackURL': 'http://localhost:3500/social/auth/linkedin/callback'
    // 'callbackURL': 'https://supergigs-dev.herokuapp.com/social/auth/linkedin/callback'

  }
}

